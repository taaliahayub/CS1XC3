/**
 * @file student.h
 * @author Taaliah Ayub
 * @brief Student library for managing student grades, including
 *        definitions for Student type and student & grade functions.
 * @date 2022-04-10
 * 
 */


/**
 * @brief Student typedef stores a student with fields first name,
 *        last name, id, grades, and number of grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< students first name >*/
  char last_name[50]; /**< students last name >*/
  char id[11]; /**< students 10-digit ID >*/
  double *grades; /**< pointer to array of students grades >*/
  int num_grades; /**< no. of grades of student >*/
} Student;


void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
