/**
 * @file course.c
 * @author Taaliah Ayub
 * @brief Course library for managing courses and course enrolment, including
 *        implementations of functions predefined in the header file.
 * @date 2022-04-10
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Enrolls a student into a course
 * 
 * @param course 
 * @param student 
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // allocate memory for an array of students consisting of one student
  // if memory is allocated, reallocate enough for one more student in the preexisting array
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // update the courses array of students
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints course info incl. course name, course code, total # of students,
 *        and each students info
 * 
 * @param course 
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // loop through the number of students and print student info for
  // each index in the array
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Determines student with the highest average in a given course
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // loop through a courses array of students to 
  // find the one with the highest average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Determines which students are passing a given course
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // increment count var for each student with a passing grade
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // allocate memory for an array the size of
  // the number of students that are passing
  passing = calloc(count, sizeof(Student));
  
  // for each student in the course, if they have
  // a passing grade, add them to the array
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}