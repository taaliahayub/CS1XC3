/**
 * @mainpage Demonstration of libraries for creating courses with students
 * 
 * Displays the functionality of multiple methods defined and implemented
 * in the student and course libraries, including:
 * - generating a random student
 * - enrolling a student into a course
 * - printing course and student info
 * - finding the top student of a course
 * - finding which students are passing a course
 * 
 * @file main.c
 * @author Taaliah Ayub 
 * @brief Runs demonstration code for methods from student and course libraries
 * @date 2022-04-10
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  // prevents repetition of generated number sequences in functions that use rand()
  // e.g. generate_random_student()
  srand((unsigned) time(NULL));

  // create a new math course and enroll 20 randomly generated students into the new course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);


  // initialize a student that will store the return value of top_student()
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);


  int total_passing;
  // initialize an array of students that will store the return value of passing()
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  // loop through the array of passing students using total_passing and print each student
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}