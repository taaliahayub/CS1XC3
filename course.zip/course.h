/**
 * @file course.h
 * @author Taaliah Ayub
 * @brief Course library for managing courses, including definitions
 *        for Course type and course & student functions.
 * @date 2022-04-10
 * 
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Course typedef stores a course with fields name, code,
 *        students, and total students.
 * 
 */
typedef struct _course 
{
  char name[100]; /**< name of course >*/
  char code[10]; /**< corresponding course code >*/
  Student *students; /**< pointer to array of students >*/
  int total_students; /**< total number of students in course >*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


