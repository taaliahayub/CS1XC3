var searchData=
[
  ['student_2ec_32',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh_33',['student.h',['../student_8h.html',1,'']]]
];
